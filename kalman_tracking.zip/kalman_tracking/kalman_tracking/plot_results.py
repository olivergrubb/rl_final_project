import matplotlib.pyplot as plt

# Read the file
file_path = "/home/ollie/ros2_ws/src/kalman_tracking/kalman_tracking/Results.txt"
with open(file_path, "r") as file:
    lines = file.readlines()

# Extract the data
x_estimated = []
y_estimated = []
x_actual = []
y_actual = []
time = []
for line in lines:
    values = line.strip().split()
    x_estimated.append(float(values[0]))
    y_estimated.append(float(values[1]))
    x_actual.append(float(values[2]))
    y_actual.append(float(values[3]))
    time.append(len(time) * 0.5)  # Each reading is 0.5 seconds apart

# Plot the data
plt.plot(time, x_actual, label="Actual", color="red")
plt.plot(time, x_estimated, label="Estimated", color="blue")
plt.xlabel("Time (seconds)")
plt.ylabel("Y Position")
plt.title("Difference between Estimated and Actual X values over Time")
plt.show()
